from client import ftp_client

if __name__ == "__main__":
    ftp_client = ftp_client()
