//
//  NumberCollectionViewCell.swift
//  CS 496 - HW 4
//
//  Created by Dring, Brandon on 2/17/18.
//  Copyright © 2018 Dring, Brandon. All rights reserved.
//

import UIKit

class NumberCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var NumberLabel: UILabel!
}
