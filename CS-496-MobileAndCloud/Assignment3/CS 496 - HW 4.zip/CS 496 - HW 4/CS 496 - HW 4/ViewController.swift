//
//  ViewController.swift
//  CS 496 - HW 4
//
//  Created by Dring, Brandon on 2/16/18.
//  Copyright © 2018 Dring, Brandon. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    /**** Properties ***/
    @IBOutlet weak var ListView: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    
    /*** Actions ***/
    @IBAction func buttonClicked() {
//        print("FOO");
    }
}

