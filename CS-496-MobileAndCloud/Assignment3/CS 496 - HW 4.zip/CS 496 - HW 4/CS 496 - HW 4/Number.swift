//
//  Number.swift
//  CS 496 - HW 4
//
//  Created by Dring, Brandon on 2/16/18.
//  Copyright © 2018 Dring, Brandon. All rights reserved.
//

import Foundation

class Number {
    public var numbers = [1...100];
    var number: Int
    
    init( number: Int ) {
        self.number = number;
    }
}
