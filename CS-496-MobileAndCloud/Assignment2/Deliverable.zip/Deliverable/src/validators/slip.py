

class slip_validator:
    def __init__(self):
        pass
